package com.example.rickandmorty.data.repository

import com.example.rickandmorty.data.local.CharacterDao
import com.example.rickandmorty.data.remote.RickAndMortyApi
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class CharacterRepository @Inject constructor(
    private val api: RickAndMortyApi,
    private val dao: CharacterDao
) {

    val characters = dao.getAll().map { list -> list.map { it.toModel() } }

    suspend fun refresh() {
        val remote = api.getCharacters().results.map { it.toEntity() }
        dao.insertAll(remote)
    }
}