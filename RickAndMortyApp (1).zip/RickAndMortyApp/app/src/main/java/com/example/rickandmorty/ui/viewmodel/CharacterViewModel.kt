package com.example.rickandmorty.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.rickandmorty.data.repository.CharacterRepository
import com.example.rickandmorty.domain.usecase.GetCharactersUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CharacterViewModel @Inject constructor(
    private val getCharacters: GetCharactersUseCase,
    private val repo: CharacterRepository
) : ViewModel() {

    val characters: LiveData<List<com.example.rickandmorty.domain.model.Character>> =
        getCharacters().asLiveData()

    fun refresh() = viewModelScope.launch {
        repo.refresh()
    }
}