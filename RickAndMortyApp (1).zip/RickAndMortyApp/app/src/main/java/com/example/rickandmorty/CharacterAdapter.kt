package com.example.rickandmorty

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.rickandmorty.databinding.ItemCharacterBinding
import com.example.rickandmorty.domain.model.Character

class CharacterAdapter :
    ListAdapter<Character, CharacterAdapter.VH>(diff) {

    object diff : DiffUtil.ItemCallback<Character>() {
        override fun areItemsTheSame(a: Character, b: Character) = a.id == b.id
        override fun areContentsTheSame(a: Character, b: Character) = a == b
    }

    inner class VH(val vb: ItemCharacterBinding) :
        RecyclerView.ViewHolder(vb.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemCharacterBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        holder.vb.name.text = item.name
        Glide.with(holder.vb.image).load(item.image).into(holder.vb.image)
    }
}