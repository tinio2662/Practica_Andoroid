package com.example.rickandmorty.data.repository

import com.example.rickandmorty.data.local.CharacterEntity
import com.example.rickandmorty.data.remote.CharacterDto
import com.example.rickandmorty.domain.model.Character

fun CharacterDto.toEntity() = CharacterEntity(id, name, image)
fun CharacterEntity.toModel() = Character(id, name, image)