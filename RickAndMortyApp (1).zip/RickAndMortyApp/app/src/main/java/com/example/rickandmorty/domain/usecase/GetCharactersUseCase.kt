package com.example.rickandmorty.domain.usecase

import com.example.rickandmorty.data.repository.CharacterRepository
import javax.inject.Inject

class GetCharactersUseCase @Inject constructor(
    private val repo: CharacterRepository
) {
    operator fun invoke() = repo.characters
}